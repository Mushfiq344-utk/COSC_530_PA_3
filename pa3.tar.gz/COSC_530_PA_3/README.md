# COSC_530_PA_3 12/08/2025
The dotprod_performance.pdf has the bargraph.