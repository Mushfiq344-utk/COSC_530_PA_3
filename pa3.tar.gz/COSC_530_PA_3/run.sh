echo ==== reg  ====
./reg
echo ==== ur4  ====
./ur4
echo ==== ae4  ====
./ae4
echo ==== sse ====
./sse
